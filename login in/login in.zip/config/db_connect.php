
<?php 

//MySQL
	//Connect to DataBase
	$conn =mysqli_connect('localhost','ahmed','1732001','elsoltan_pizza');

	//check the connection
	if(!$conn){
		 echo 'connection error:'.mysqli_connect_error();
	
	}








 ?>